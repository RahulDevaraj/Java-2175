import java.util.Scanner;

/**
 * Driver class for Item and CashRegister
 * @author Rahul
 *
 */
public class Driver {
	/** 
	 * main method
	 * @param args
	 */
public static void main(String[] args) {
	
	String name;	//for storing item name
	float price;	//for storing item price
	int quantity;	//for storing item quantity
	
	Scanner sc = new Scanner(System.in);
	System.out.println("Welcome to CashRegister app\n"
			+ "Enter name of the item purchased");
	
	name = sc.nextLine();	//getting name
	
	System.out.println("Enter quantity of item purchased ");
	quantity = sc.nextInt();	//getting quantity
	
	System.out.println("Enter price of 1 item");
	price = sc.nextFloat();		//getting price
	
	Item item = new Item(name, price);			//Initializing objects using constructor
	CashRegister cashRegister = new CashRegister(quantity);	
	
	float subTotal = cashRegister.calculateSubtotal(item);	//Calc subTotal
	float total = cashRegister.calculateTotal(subTotal);	//Calc total
	
	System.out.println("The price of "+quantity+" "+item.getName()+" is $"+total+" including tax.");	//Printing results
	
	
}
}
