/**
 * CashRegister class definition
 * @author Rahul
 *
 */
public class CashRegister {
	private int quantity;	//Quantity of item

	/**
	 * Constructor for initialising CashRegister Class
	 * @param quantity
	 */
	public CashRegister(int quantity) {
		
		this.quantity = quantity;
	}
	
	/**
	 * Calculate Subtotal
	 * @param item
	 * @return float
	 */
	public float calculateSubtotal(Item item)
	{
		return (float)(item.getPrice()*quantity);	//price * quantity
	}
	
	/**
	 * Calculate Total
	 * @param subTotal
	 * @return float
	 */
	public float calculateTotal(float subTotal)
	{
		return (float)(1.075*subTotal);	//total = tax + subTotal
	}

}
