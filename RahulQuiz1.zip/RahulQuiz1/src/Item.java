/**
 * Item class definition
 * @author Rahul
 *
 */
public class Item {
	
	private String name;	//item name
	private float price;	//item price
	
	/**
	 * Constructor for initialising Item Class
	 * @param name
	 * @param price
	 */
	public Item(String name, float price) {
		
		this.name = name;
		this.price = price;
	}
	/**
	 * 
	 * Get method to retrieve the item name
	 * @return String
	 */
	public String getName() {
		return name;
	}
	/**
	 * 
	 * Get method to retrieve the item price
	 * @return float
	 */
	public float getPrice() {
		return price;
	}

}
